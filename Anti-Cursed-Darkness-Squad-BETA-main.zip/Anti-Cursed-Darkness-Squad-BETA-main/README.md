# Anti-Cursed-Darkness-Squad-BETA
Cloudflare JS Challenge Bypass<br>Cloudflare Captcha Bypass<br>Strong DDOS Layer 7<br>Private Tool<br><br>
# Picture:
![GitHub Logo](home.png)

# Installation
<code>sudo apt update</code><br>
<code>sudo apt install git</code><br>
<code>git clone https://github.com/Z3NTL3/Anti-Cursed-Darkness-Squad-BETA/</code><br>
<code>cd Anti-Cursed-Darkness-Squad-BETA</code><br>
<code>chmod +x installer</code><br>
<code>./installer</code><br>
<code>python3 darkness.py</code><br>
<code>Password: I'ts private sorry</code>
